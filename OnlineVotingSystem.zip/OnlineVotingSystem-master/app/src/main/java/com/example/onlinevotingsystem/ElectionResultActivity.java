package com.example.onlinevotingsystem;

public class ElectionResultActivity {
}
